class Carro:
   voltas = 0
   posicao = 0
   velocidade = 0
   def __init__(self, param):
      self.velocidade = param
   def andacarro1s(self):
      self.posicao = self.velocidade + self.posicao
      if (self.posicao >= 50):
         self.posicao=self.posicao-50
         self.voltas = self.voltas+1

carro1 = Carro(1)
carro2 = Carro(3)
voltasqueseencontram=0;
while (carro1.voltas <= 10000):
   carro1.andacarro1s()
   carro2.andacarro1s()
   if (carro1.posicao == carro2.posicao):
      voltasqueseencontram = voltasqueseencontram +1
print(voltasqueseencontram)
